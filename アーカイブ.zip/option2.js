if (lang() == "ja") {
  document.getElementById("menu").innerHTML = "<div>機能</div><div>ボタン</div><div>挨拶</div><div>初期化</div><div>情報</div><div>連絡</div>";
}
else {
    document.getElementById("menu").innerHTML = "<div>Function</div><div>Button</div><div>Greeting</div><div>Initialization</div><div>Information</div><div>Contact</div>";
}
